# -*- coding: utf-8 -*-
import os
import math
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QComboBox,
    QSpinBox, QPushButton, QTableWidget, QTableWidgetItem,
    QTextBrowser, QTabWidget, QWidget, QGroupBox, QHeaderView, QMessageBox,
    QProgressBar, QCheckBox, QApplication, QFrame
)
from qgis.PyQt.QtCore import Qt, QVariant, QSize, QPointF, QRectF
from qgis.PyQt.QtGui import QColor, QIcon, QPixmap, QFont, QPainter, QPolygonF, QPen, QBrush
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
    QgsField, QgsFields, QgsWkbTypes, QgsCategorizedSymbolRenderer,
    QgsRendererCategory, QgsFillSymbol, QgsCoordinateTransform
)
from .mpyy_engine import FastRoadGraph, split_polygon_by_ratios

DEFAULT_MPYY_FACILITIES = [
    ("ilkokul", "İlkokul (EK-2: 5000-8000 m²)", "Primary School (5000-8000 m²)", "小学 (5000-8000 m²)", "Escuela Primaria (5000-8000 m²)", 500.0, 500.0, 2.0, 5000.0, 8000.0, 2500, "#38bdf8", ["ilkokul", "ilk_okul", "primary"]),
    ("ortaokul", "Ortaokul (EK-2: 6000-10000 m²)", "Middle School (6000-10000 m²)", "初中 (6000-10000 m²)", "Escuela Secundaria (6000-10000 m²)", 1000.0, 1000.0, 2.0, 6000.0, 10000.0, 3500, "#1d4ed8", ["ortaokul", "orta_okul", "middle"]),
    ("lise", "Gündüzlü Lise (EK-2: 6000-10000 m²)", "Day High School (6000-10000 m²)", "日制高中 (6000-10000 m²)", "Preparatoria Diurna (6000-10000 m²)", 2500.0, 2500.0, 2.0, 6000.0, 10000.0, 5000, "#8b5cf6", ["lise", "high"]),
    ("asm", "Aile Sağlığı Merkezi (EK-2: 750-2000 m²)", "Family Health Center (750-2000 m²)", "社区卫生服务中心 (750-2000 m²)", "Centro de Salud Familiar (750-2000 m²)", 500.0, 500.0, 0.75, 750.0, 2000.0, 5000, "#ff8a8a", ["asm", "aile_sagligi", "saglik_ocagi"]),
    ("hastane", "Devlet Hastanesi (EK-2: 1.5 m²/kişi)", "State Hospital (1.5 m²/cap)", "国立医院 (1.5 m²/人)", "Hospital Estatal (1.5 m²/pers)", 2500.0, 2500.0, 1.50, 5000.0, 15000.0, 15000, "#5c0000", ["hastane", "saglik", "hospital"]),
    ("ibadet", "Orta İbadet Yeri (EK-2: 2500 m²)", "Place of Worship (2500 m²)", "宗教场所 (2500 m²)", "Lugar de Culto (2500 m²)", 400.0, 400.0, 0.50, 2500.0, 5000.0, 3500, "#f59e0b", ["ibadet", "cami", "mescit", "dini"]),
    ("park", "Çocuk Bahçesi & Park (EK-2: 10 m³/kişi)", "Park & Playground (10 m³/cap)", "公园与儿童乐园 (10 m³/人)", "Parque y Juegos (10 m³/pers)", 500.0, 500.0, 10.0, 1000.0, 25000.0, 3000, "#10b981", ["park", "yesil", "cocuk"]),
    ("konut", "Gelişme Konut Alanı (Rezerv Yapı)", "Residential Development Area", "居住发展用地 (储备)", "Área de Desarrollo Residencial", 1000.0, 1000.0, 0.0, 1000.0, 30000.0, 4000, "#fde047", ["konut", "gelisme", "residential"]),
    ("sosyal", "Sosyal ve Kültürel Tesis (EK-2)", "Social & Cultural Facility", "社会与文化设施", "Instalación Social y Cultural", 1000.0, 1000.0, 1.25, 1500.0, 6000.0, 4000, "#0d9488", ["sosyal", "kulturel", "kultur"]),
]

TRANSLATIONS = {
    "tr": {
        "win_title": "MPYY Donatı Erişilebilirlik ve Optimizasyon — by Baran Adsuna",
        "banner_title": "MEKÂNSAL PLANLAR YAPIM YÖNETMELİĞİ (MPYY) EK-2 STANDARTLARI & AKILLI OPTİMİZASYON",
        "banner_sub": "Fazla Donatı Tespiti • Gelişme Konut Alanı Ataması • EK-2 Tablo Uyumu • Otomatik İfraz",
        "dev_label": "⚡ Geliştirici / Yazar",
        "tab1": "1. Poligon Katmanları ve EK-2 Standart Tablosu",
        "tab2": "2. Detaylı Plan Açıklama ve Erişilebilirlik Raporu",
        "grp1": "1. Temel Harita Katmanları (Poligonlar Arka Planda Otomatik Noktaya Dönüştürülür)",
        "lbl_net": "<b>Prepared Network (Yol Ağı - Çizgi):</b>",
        "lbl_res": "<b>Mevcut Konut Adaları (Poligon):</b>",
        "lbl_vac": "<b>Boş Alanlar / İmar Adaları (Poligon - Bölünecek):</b>",
        "chk_centroids": "Poligonlardan otomatik üretilen ağırlık merkezi noktalarını haritada göster",
        "grp2": "2. Planlama Alanı Nüfusu ve Akıllı Donatı Yeterlilik Ayarı",
        "lbl_pop": "<b>Toplam Planlama Alanı Nüfusu (Kişi):</b>",
        "lbl_pop_note": "*(Konut adalarının alanları (m²) oranında nüfus otomatik dağıtılır)*",
        "lbl_split": "<b>Akıllı Yeterlilik & Gelişme Konut Alanı:</b>",
        "chk_split": "Çevrede ibadet, okul vb. donatılar fazlaysa yeni okul/cami yığmak yerine adayı 'Gelişme Konut Alanı' veya Park olarak değerlendir",
        "grp3": "3. EK-2 Sosyal ve Teknik Altyapı Alanları Standartları Tablosu (Tamamen Düzenlenebilir)",
        "col_name": "Altyapı Alanı / Donatı\n(EK-2 Standart & Renk)",
        "col_layer": "Mevcut Poligon Katmanı\n(Haritadan Seç)",
        "col_euclid": "MPYY Kuş Uçuşu\nYarıçap (m)",
        "col_net": "Yol Üzerinden\nErişim (m)",
        "col_std": "EK-2 Kişi Başı Standart\n(m²/kişi veya m³/kişi)",
        "col_min": "EK-2 Asgari Birim Alan\n(Min m²)",
        "col_max": "Bölme Eşiği\n(Max Tekil m²)",
        "col_cap": "1 Bina Kapasitesi\n(Kişi Sayısı)",
        "btn_add": "➕ Yeni Donatı Satırı Ekle",
        "btn_del": "🗑️ Seçili Satırı Sil",
        "btn_reset": "🔄 EK-2 Tablo Normlarına Sıfırla",
        "btn_demo": "🚀 Örnek Poligon Test Verisi Oluştur",
        "btn_run": "⚡ AKILLI EK-2 ANALİZİNİ BAŞLAT VE HARİTAYA İŞLE",
        "none_layer": "-- Yok / Alanda Mevcut Değil --",
        "new_fac": "Yeni Donatı",
        "empty_report": "<h3>Henüz analiz çalıştırılmadı.</h3><p>Lütfen katmanlarınızı seçip <b>ANALİZİ BAŞLAT</b> butonuna tıklayın.</p>",
        "warn_missing_title": "Eksik Katman",
        "warn_missing_msg": "Lütfen Prepared Network (Yol Ağı), Mevcut Konut Adaları (Poligon) ve Boş Alan (Poligon) katmanlarını seçiniz!",
        "done_title": "Akıllı Analiz ve Optimizasyon Tamamlandı",
        "done_msg": "Bölünen ve önerilen donatı / konut gelişme alanları ('MPYY_Onerilen_ve_Bolunen_Donati_Alanlari') haritaya eklendi! (Bölgelerdeki mevcut donatı yeterliliği denetlenerek gereksiz yığılmalar önlendi.)"
    },
    "en": {
        "win_title": "MPYY Urban Facility Accessibility & Optimization — by Baran Adsuna",
        "banner_title": "SPATIAL PLANS CONSTRUCTION REGULATION (MPYY) ANNEX-2 STANDARDS & SMART SUPPORT",
        "banner_sub": "Surplus Facility Check • Residential Development Area Assignment • Annex-2 Table Compliance • Auto Split",
        "dev_label": "⚡ Developer / Author",
        "tab1": "1. Polygon Layers & Annex-2 Standard Table",
        "tab2": "2. Detailed Planning & Accessibility Report",
        "grp1": "1. Base Map Layers (Polygons Are Automatically Converted to Centroids in Background)",
        "lbl_net": "<b>Prepared Network (Road Graph - Line):</b>",
        "lbl_res": "<b>Existing Residential Blocks (Polygon):</b>",
        "lbl_vac": "<b>Vacant Parcels / Urban Blocks (Polygon - To Split):</b>",
        "chk_centroids": "Display automatically generated centroid points on map",
        "grp2": "2. Planning Area Population & Smart Facility Sufficiency Rule",
        "lbl_pop": "<b>Total Planning Area Population (Persons):</b>",
        "lbl_pop_note": "*(Population weighted by residential block area m²)*",
        "lbl_split": "<b>Smart Sufficiency & Residential Growth:</b>",
        "chk_split": "If surrounding schools/mosques are sufficient, assign vacant parcels as 'Residential Development Area' or Park instead of piling up duplicates",
        "grp3": "3. Annex-2 Social & Technical Infrastructure Standards Table (Fully Editable)",
        "col_name": "Infrastructure / Facility\n(Annex-2 Std & Color)",
        "col_layer": "Existing Polygon Layer\n(Select from Map)",
        "col_euclid": "Euclidean\nRadius (m)",
        "col_net": "Road Network\nDistance (m)",
        "col_std": "Annex-2 Per Capita\n(m²/cap or m³/cap)",
        "col_min": "Annex-2 Min Unit Area\n(Min m²)",
        "col_max": "Split Threshold\n(Max Single m²)",
        "col_cap": "1 Building Cap\n(Persons)",
        "btn_add": "➕ Add Facility Row",
        "btn_del": "🗑️ Remove Selected Row",
        "btn_reset": "🔄 Reset to Annex-2 Norms",
        "btn_demo": "🚀 Generate Sample Polygon Data",
        "btn_run": "⚡ RUN SMART ANNEX-2 ANALYSIS & RENDER ON MAP",
        "none_layer": "-- None / Not Present in Area --",
        "new_fac": "New Facility",
        "empty_report": "<h3>Analysis has not been run yet.</h3><p>Please select your layers and click <b>RUN ANALYSIS</b>.</p>",
        "warn_missing_title": "Missing Layer",
        "warn_missing_msg": "Please select Prepared Network (Line), Existing Residential Blocks (Polygon), and Vacant Parcels (Polygon)!",
        "done_title": "Smart Analysis & Optimization Complete",
        "done_msg": "Split and allocated facility / residential growth polygons ('MPYY_Onerilen_ve_Bolunen_Donati_Alanlari') have been added to the map! (Surplus facilities checked, preventing redundant clustering.)"
    },
    "zh": {
        "win_title": "MPYY 城市公共设施可达性与空间优化系统 — by Baran Adsuna",
        "banner_title": "空间规划建设管理条例 (MPYY) 附表2标准与智能决策支持系统",
        "banner_sub": "冗余设施检测 • 居住发展用地分配 • 附表2标准合规 • 自动分割",
        "dev_label": "⚡ 开发者 / 作者",
        "tab1": "1. 多边形图层与附表2标准参数表",
        "tab2": "2. 详细规划说明与可达性报告",
        "grp1": "1. 基础地图图层（多边形在后台自动转换为质心点）",
        "lbl_net": "<b>路网图层 Prepared Network（线）：</b>",
        "lbl_res": "<b>现有居住街坊（多边形）：</b>",
        "lbl_vac": "<b>空置地块 / 待规划街坊（多边形 - 自动分割）：</b>",
        "chk_centroids": "在地图上显示自动生成的质心点图层",
        "grp2": "2. 规划区总人口与智能设施充足性规则",
        "lbl_pop": "<b>规划区总人口（人 - 手动输入）：</b>",
        "lbl_pop_note": "*（按居住街坊面积比例分配人口）*",
        "lbl_split": "<b>智能充足性与居住发展：</b>",
        "chk_split": "若周边学校/宗教设施已足够，则将空置地块分配为“居住发展用地”或公园，而非盲目堆砌",
        "grp3": "3. 附表2社会与技术基础设施标准表（法规官方数值 - 可完全编辑）",
        "col_name": "基础设施 / 设施\n（附表2标准与颜色）",
        "col_layer": "现有多边形图层\n（从地图选择）",
        "col_euclid": "直线服务\n半径 (m)",
        "col_net": "路网步行\n距离 (m)",
        "col_std": "附表2人均指标\n(m²/人 或 m³/人)",
        "col_min": "附表2最小单元面积\n(Min m²)",
        "col_max": "分割阈值\n(Max m²)",
        "col_cap": "单体建筑容量\n(人数)",
        "btn_add": "➕ 添加新设施行",
        "btn_del": "🗑️ 删除选中行",
        "btn_reset": "🔄 重置为附表2规范",
        "btn_demo": "🚀 生成示例多边形测试数据",
        "btn_run": "⚡ 开始智能附表2分析并渲染至地图",
        "none_layer": "-- 无 / 区域内不存在 --",
        "new_fac": "新公共设施",
        "empty_report": "<h3>尚未运行分析。</h3><p>请选择图层并点击<b>开始分析</b>按钮。</p>",
        "warn_missing_title": "缺少图层",
        "warn_missing_msg": "请选择路网图层、现有居住街坊和空置地块！",
        "done_title": "智能分析与空间优化已完成",
        "done_msg": "配建的设施及居住发展用地多边形 ('MPYY_Onerilen_ve_Bolunen_Donati_Alanlari') 已添加到地图！"
    },
    "es": {
        "win_title": "MPYY Accesibilidad de Instalaciones Urbanas y Optimización — by Baran Adsuna",
        "banner_title": "SISTEMA DE SOPORTE DE DECISIONES DE PLANES ESPACIALES (MPYY) - ESTÁNDARES ANEXO-2",
        "banner_sub": "Chequeo de Excedentes • Asignación de Área de Desarrollo Residencial • Cumplimiento Anexo-2 • División Auto",
        "dev_label": "⚡ Desarrollador / Author",
        "tab1": "1. Capas de Polígonos y Tabla Anexo-2",
        "tab2": "2. Informe Detallado de Planificación y Accesibilidad",
        "grp1": "1. Capas de Mapa Base (Los polígonos se convierten automáticamente a centroides en segundo plano)",
        "lbl_net": "<b>Red Preparada (Prepared Network - Línea):</b>",
        "lbl_res": "<b>Manzanas Residenciales Existentes (Polígono):</b>",
        "lbl_vac": "<b>Parcelas Vacantes / Bloques Urbanos (Polígono - A Dividir):</b>",
        "chk_centroids": "Mostrar centroides generados automáticamente en el mapa",
        "grp2": "2. Población del Área de Planificación y Suficiencia Inteligente",
        "lbl_pop": "<b>Población Total del Área de Planificación (Personas):</b>",
        "lbl_pop_note": "*(Población ponderada por área de manzana residencial)*",
        "lbl_split": "<b>Suficiencia Inteligente y Crecimiento Residencial:</b>",
        "chk_split": "Si las escuelas/mezquitas circundantes son suficientes, asigne parcelas vacantes como 'Área de Desarrollo Residencial' o Parque en lugar de duplicados",
        "grp3": "3. Tabla de Estándares Anexo-2 (Valores Oficiales del Reglamento - Completamente Editable)",
        "col_name": "Infraestructura / Instalación\n(Estándar Anexo-2 y Color)",
        "col_layer": "Capa de Polígono Existente\n(Seleccionar del Mapa)",
        "col_euclid": "Radio Euclidiano\n(m)",
        "col_net": "Distancia de Red\nVial (m)",
        "col_std": "Estándar Anexo-2 Per Cápita\n(m²/pers o m³/pers)",
        "col_min": "Área Mínima Anexo-2\n(Mín m²)",
        "col_max": "Umbral de División\n(Máx m²)",
        "col_cap": "Capacidad de 1 Edificio\n(Personas)",
        "btn_add": "➕ Agregar Fila de Instalación",
        "btn_del": "🗑️ Eliminar Fila Seleccionada",
        "btn_reset": "🔄 Restablecer Normas Anexo-2",
        "btn_demo": "🚀 Generar Datos de Prueba Poligonales",
        "btn_run": "⚡ EJECUTAR ANÁLISIS INTELIGENTE ANEXO-2 Y RENDERIZAR EN MAPA",
        "none_layer": "-- Ninguno / No presente en el área --",
        "new_fac": "Nueva Instalación",
        "empty_report": "<h3>El análisis aún no se ha ejecutado.</h3><p>Seleccione sus capas y haga clic en <b>EJECUTAR ANÁLISIS</b>.</p>",
        "warn_missing_title": "Capa Faltante",
        "warn_missing_msg": "¡Seleccione la Red Preparada, Bloques Residenciales y Parcelas Vacantes!",
        "done_title": "Análisis Inteligente Anexo-2 Completado",
        "done_msg": "¡Los polígonos asignados ('MPYY_Onerilen_ve_Bolunen_Donati_Alanlari') se han agregado al mapa! (Se verificó la suficiencia evitando aglomeraciones y asignando áreas residenciales donde ya hay suficientes dotaciones)."
    }
}

MODERN_STYLE = """
QDialog {
    background-color: #f8fafc;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 12px;
    color: #0f172a;
}
QGroupBox {
    background-color: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    margin-top: 10px;
    padding-top: 14px;
    font-weight: bold;
    color: #0f172a;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 12px;
    padding: 0 6px;
    color: #1d4ed8;
}
QTabWidget::pane {
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    background: #ffffff;
}
QTabBar::tab {
    background: #e2e8f0;
    color: #334155;
    padding: 8px 22px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    margin-right: 4px;
    font-weight: bold;
    min-width: 240px;
}
QTabBar::tab:selected {
    background: #1e40af;
    color: #ffffff;
}
QComboBox, QSpinBox {
    border: 1px solid #94a3b8;
    border-radius: 5px;
    padding: 3px 8px;
    background-color: #ffffff;
    color: #0f172a;
    min-height: 24px;
}
QComboBox:focus, QSpinBox:focus {
    border: 1.5px solid #2563eb;
}
QTableWidget {
    background-color: #ffffff;
    alternate-background-color: #f8fafc;
    gridline-color: #cbd5e1;
    border: 1px solid #94a3b8;
    border-radius: 6px;
    font-size: 12px;
    color: #0f172a;
    selection-background-color: #dbeafe;
    selection-color: #0f172a;
}
QHeaderView::section {
    background-color: #0f172a;
    color: #ffffff;
    font-weight: bold;
    font-size: 11px;
    padding: 6px 4px;
    border: 1px solid #334155;
}
QPushButton {
    background-color: #e2e8f0;
    color: #0f172a;
    border: 1px solid #94a3b8;
    border-radius: 6px;
    padding: 6px 14px;
    font-weight: bold;
}
QPushButton:hover {
    background-color: #cbd5e1;
}
QProgressBar {
    border: 1px solid #94a3b8;
    border-radius: 6px;
    text-align: center;
    background-color: #e2e8f0;
    font-weight: bold;
    color: #0f172a;
    min-height: 28px;
}
QProgressBar::chunk {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #2563eb, stop:1 #06b6d4);
    border-radius: 5px;
}
"""

def _draw_star(painter, cx, cy, r_outer, r_inner, angle_deg=0.0):
    pts = []
    for i in range(10):
        ang = math.radians(angle_deg + i * 36.0)
        r = r_outer if i % 2 == 0 else r_inner
        pts.append(QPointF(cx + r * math.cos(ang), cy + r * math.sin(ang)))
    painter.drawPolygon(QPolygonF(pts))

def create_flag_icon(lang_code):
    w, h = 36, 24
    pix = QPixmap(w, h)
    pix.fill(Qt.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.Antialiasing)

    if lang_code == "tr":
        p.fillRect(0, 0, w, h, QColor("#E30A17"))
        p.setBrush(QColor("#FFFFFF"))
        p.setPen(Qt.NoPen)
        p.drawEllipse(QPointF(13.0, 12.0), 6.5, 6.5)
        p.setBrush(QColor("#E30A17"))
        p.drawEllipse(QPointF(14.8, 12.0), 5.2, 5.2)
        p.setBrush(QColor("#FFFFFF"))
        _draw_star(p, 22.8, 12.0, 3.4, 1.3, angle_deg=-18.0)
    elif lang_code == "en":
        p.fillRect(0, 0, w, h, QColor("#012169"))
        pen_w_diag = QPen(QColor("#FFFFFF"), 4.6)
        p.setPen(pen_w_diag)
        p.drawLine(0, 0, w, h)
        p.drawLine(0, h, w, 0)
        pen_r_diag = QPen(QColor("#C8102E"), 2.0)
        p.setPen(pen_r_diag)
        p.drawLine(0, 0, w, h)
        p.drawLine(0, h, w, 0)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#FFFFFF"))
        p.drawRect(QRectF(0, 8, w, 8))
        p.drawRect(QRectF(14, 0, 8, h))
        p.setBrush(QColor("#C8102E"))
        p.drawRect(QRectF(0, 9.6, w, 4.8))
        p.drawRect(QRectF(15.6, 0, 4.8, h))
    elif lang_code == "zh":
        p.fillRect(0, 0, w, h, QColor("#DE2910"))
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#FFDE00"))
        _draw_star(p, 7.5, 7.5, 4.2, 1.6, angle_deg=-90.0)
        for sx, sy in [(14.5, 3.0), (17.2, 5.8), (17.2, 9.8), (14.5, 12.6)]:
            _draw_star(p, sx, sy, 1.6, 0.65, angle_deg=-70.0)
    elif lang_code == "es":
        p.fillRect(0, 0, w, h, QColor("#AA151B"))
        p.setBrush(QColor("#F1BF00"))
        p.setPen(Qt.NoPen)
        p.drawRect(QRectF(0, 6, w, 12))
        p.setBrush(QColor("#AA151B"))
        p.drawRect(QRectF(5, 8, 4, 8))

    p.setPen(QPen(QColor(0, 0, 0, 60), 1.0))
    p.setBrush(Qt.NoBrush)
    p.drawRect(QRectF(0, 0, w - 1, h - 1))
    p.end()
    return QIcon(pix)

def create_color_swatch_icon(hex_color):
    pix = QPixmap(18, 18)
    pix.fill(Qt.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.Antialiasing)
    p.setBrush(QColor(hex_color))
    p.setPen(QPen(QColor("#1e293b"), 1.2))
    p.drawRoundedRect(QRectF(1, 1, 16, 16), 4, 4)
    p.end()
    return QIcon(pix)

class MPYYDonatiDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.current_lang = "tr"
        self.resize(1220, 840)
        self.setStyleSheet(MODERN_STYLE)
        self.setup_ui()
        self.apply_language("tr")

    def setup_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(8)

        banner = QFrame()
        banner.setStyleSheet(
            "background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0f172a, stop:0.6 #1e3a8a, stop:1 #1d4ed8);"
            "border-radius: 8px; padding: 8px;"
        )
        banner_layout = QHBoxLayout(banner)

        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        logo_lbl = QLabel()
        if os.path.exists(icon_path):
            logo_lbl.setPixmap(QPixmap(icon_path).scaled(48, 48, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        logo_lbl.setFixedSize(52, 52)
        logo_lbl.setStyleSheet("background: transparent;")
        banner_layout.addWidget(logo_lbl)

        self.title_lbl = QLabel()
        self.title_lbl.setStyleSheet("background: transparent;")
        banner_layout.addWidget(self.title_lbl, stretch=1)

        lang_box = QVBoxLayout()
        self.cmb_lang = QComboBox()
        self.cmb_lang.setIconSize(QSize(28, 18))
        self.cmb_lang.setFixedWidth(185)
        self.cmb_lang.setStyleSheet(
            "QComboBox { background-color: #ffffff; color: #0f172a; font-weight: bold; font-size: 12px; border-radius: 5px; padding: 4px 8px; }"
        )
        self.cmb_lang.addItem(create_flag_icon("tr"), "Türkçe (TR)", "tr")
        self.cmb_lang.addItem(create_flag_icon("en"), "English (EN)", "en")
        self.cmb_lang.addItem(create_flag_icon("zh"), "中文 (ZH)", "zh")
        self.cmb_lang.addItem(create_flag_icon("es"), "Español (ES)", "es")
        self.cmb_lang.currentIndexChanged.connect(self.on_language_changed)
        lang_box.addWidget(self.cmb_lang)

        self.author_badge = QLabel()
        self.author_badge.setStyleSheet(
            "background-color: rgba(255,255,255,0.14); border: 1px solid rgba(255,255,255,0.28); "
            "border-radius: 6px; padding: 3px 8px;"
        )
        lang_box.addWidget(self.author_badge)
        banner_layout.addLayout(lang_box)

        main_layout.addWidget(banner)

        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        tab_inputs = QWidget()
        layout_inputs = QVBoxLayout(tab_inputs)

        self.grp_layers = QGroupBox()
        grid = QGridLayout(self.grp_layers)
        grid.setSpacing(8)

        self.lbl_net = QLabel()
        grid.addWidget(self.lbl_net, 0, 0)
        self.cmb_network = QComboBox()
        grid.addWidget(self.cmb_network, 0, 1)

        self.lbl_res = QLabel()
        grid.addWidget(self.lbl_res, 1, 0)
        self.cmb_residential_poly = QComboBox()
        grid.addWidget(self.cmb_residential_poly, 1, 1)

        self.lbl_vac = QLabel()
        grid.addWidget(self.lbl_vac, 2, 0)
        self.cmb_vacant_polys = QComboBox()
        grid.addWidget(self.cmb_vacant_polys, 2, 1)

        self.chk_show_centroids = QCheckBox()
        self.chk_show_centroids.setChecked(False)
        self.chk_show_centroids.setStyleSheet("color: #1e40af; font-weight: bold;")
        grid.addWidget(self.chk_show_centroids, 3, 0, 1, 2)

        layout_inputs.addWidget(self.grp_layers)

        self.grp_pop = QGroupBox()
        pop_grid = QGridLayout(self.grp_pop)

        self.lbl_pop = QLabel()
        pop_grid.addWidget(self.lbl_pop, 0, 0)
        self.spn_population = QSpinBox()
        self.spn_population.setRange(100, 10000000)
        self.spn_population.setValue(65000)
        self.spn_population.setSingleStep(1000)
        self.spn_population.setStyleSheet("font-weight: bold; font-size: 13px; color: #1e3a8a;")
        pop_grid.addWidget(self.spn_population, 0, 1)

        self.lbl_pop_note = QLabel()
        pop_grid.addWidget(self.lbl_pop_note, 0, 2)

        self.lbl_split = QLabel()
        pop_grid.addWidget(self.lbl_split, 1, 0)
        self.chk_auto_split = QCheckBox()
        self.chk_auto_split.setChecked(True)
        pop_grid.addWidget(self.chk_auto_split, 1, 1, 1, 2)

        layout_inputs.addWidget(self.grp_pop)

        self.grp_table = QGroupBox()
        tbl_layout = QVBoxLayout(self.grp_table)

        self.tbl_params = QTableWidget()
        self.tbl_params.setAlternatingRowColors(True)
        self.tbl_params.setIconSize(QSize(18, 18))
        self.tbl_params.setColumnCount(8)
        self.tbl_params.setWordWrap(True)

        horiz_hdr = self.tbl_params.horizontalHeader()
        horiz_hdr.setDefaultAlignment(Qt.AlignCenter)
        horiz_hdr.setFixedHeight(46)
        horiz_hdr.setSectionResizeMode(QHeaderView.Stretch)
        horiz_hdr.setSectionResizeMode(0, QHeaderView.Interactive)
        horiz_hdr.setSectionResizeMode(1, QHeaderView.Interactive)
        self.tbl_params.setColumnWidth(0, 230)
        self.tbl_params.setColumnWidth(1, 220)

        vert_hdr = self.tbl_params.verticalHeader()
        vert_hdr.setDefaultSectionSize(36)

        self.populate_default_params()
        tbl_layout.addWidget(self.tbl_params)

        btn_row = QHBoxLayout()
        self.btn_add_row = QPushButton()
        self.btn_add_row.clicked.connect(self.add_facility_row)
        self.btn_del_row = QPushButton()
        self.btn_del_row.clicked.connect(self.remove_selected_facility_row)
        self.btn_reset_mpyy = QPushButton()
        self.btn_reset_mpyy.clicked.connect(self.reset_and_populate)
        self.btn_demo = QPushButton()
        self.btn_demo.setStyleSheet("background-color: #f59e0b; color: white; border: none; padding: 6px 14px;")
        self.btn_demo.clicked.connect(self.create_demo_layers)

        btn_row.addWidget(self.btn_add_row)
        btn_row.addWidget(self.btn_del_row)
        btn_row.addWidget(self.btn_reset_mpyy)
        btn_row.addStretch()
        btn_row.addWidget(self.btn_demo)
        tbl_layout.addLayout(btn_row)

        layout_inputs.addWidget(self.grp_table, stretch=1)
        self.tabs.addTab(tab_inputs, "")

        self.tab_report = QWidget()
        layout_report = QVBoxLayout(self.tab_report)

        self.txt_report = QTextBrowser()
        self.txt_report.setOpenExternalLinks(True)
        layout_report.addWidget(self.txt_report)
        self.tabs.addTab(self.tab_report, "")

        bottom_layout = QHBoxLayout()
        self.progress = QProgressBar()
        self.progress.setValue(0)
        bottom_layout.addWidget(self.progress, stretch=2)

        self.btn_run = QPushButton()
        self.btn_run.setMinimumHeight(42)
        self.btn_run.setStyleSheet(
            "background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #1e40af, stop:1 #2563eb);"
            "color: white; font-weight: bold; font-size: 13px; padding: 6px 18px; border-radius: 6px;"
        )
        self.btn_run.clicked.connect(self.run_full_analysis)
        bottom_layout.addWidget(self.btn_run, stretch=1)

        main_layout.addLayout(bottom_layout)

    def on_language_changed(self):
        lang_code = self.cmb_lang.currentData()
        if lang_code:
            self.apply_language(lang_code)

    def apply_language(self, lang):
        self.current_lang = lang
        t = TRANSLATIONS[lang]

        self.setWindowTitle(t["win_title"])
        self.title_lbl.setText(
            f"<span style='font-size:15px; font-weight:bold; color:#ffffff;'>{t['banner_title']}</span><br>"
            f"<span style='font-size:11px; color:#bae6fd;'>{t['banner_sub']}</span>"
        )
        self.author_badge.setText(
            f"<div align='right' style='color:#fde047; font-weight:bold; font-size:10px;'>"
            f"{t['dev_label']}: <span style='color:#ffffff; font-size:11px;'>Baran Adsuna</span></div>"
        )

        self.tabs.setTabText(0, t["tab1"])
        self.tabs.setTabText(1, t["tab2"])

        self.grp_layers.setTitle(t["grp1"])
        self.lbl_net.setText(t["lbl_net"])
        self.lbl_res.setText(t["lbl_res"])
        self.lbl_vac.setText(t["lbl_vac"])
        self.chk_show_centroids.setText(t["chk_centroids"])

        self.grp_pop.setTitle(t["grp2"])
        self.lbl_pop.setText(t["lbl_pop"])
        self.lbl_pop_note.setText(t["lbl_pop_note"])
        self.lbl_split.setText(t["lbl_split"])
        self.chk_auto_split.setText(t["chk_split"])

        self.grp_table.setTitle(t["grp3"])
        self.tbl_params.setHorizontalHeaderLabels([
            t["col_name"], t["col_layer"], t["col_euclid"], t["col_net"],
            t["col_std"], t["col_min"], t["col_max"], t["col_cap"]
        ])

        self.btn_add_row.setText(t["btn_add"])
        self.btn_del_row.setText(t["btn_del"])
        self.btn_reset_mpyy.setText(t["btn_reset"])
        self.btn_demo.setText(t["btn_demo"])
        self.btn_run.setText(t["btn_run"])

        lang_idx_map = {"tr": 1, "en": 2, "zh": 3, "es": 4}
        lang_idx = lang_idx_map.get(lang, 1)

        for r in range(self.tbl_params.rowCount()):
            name_item = self.tbl_params.item(r, 0)
            if name_item:
                key_id = name_item.data(Qt.UserRole)
                if key_id:
                    for item in DEFAULT_MPYY_FACILITIES:
                        if item[0] == key_id:
                            name_item.setText(item[lang_idx])
                            break
            cmb = self.tbl_params.cellWidget(r, 1)
            if cmb and cmb.count() > 0:
                cmb.setItemText(0, t["none_layer"])

        if self.progress.value() == 0:
            self.txt_report.setHtml(t["empty_report"])

    def _create_poly_layer_combo(self, auto_keywords=None):
        t = TRANSLATIONS[self.current_lang]
        cmb = QComboBox()
        cmb.addItem(t["none_layer"], None)
        layers = QgsProject.instance().mapLayers().values()
        for lyr in layers:
            if isinstance(lyr, QgsVectorLayer) and lyr.geometryType() in (QgsWkbTypes.PolygonGeometry, QgsWkbTypes.PointGeometry):
                if lyr.name().startswith("MPYY_"):
                    continue
                cmb.addItem(lyr.name(), lyr)
        if auto_keywords:
            self._auto_select_combo(cmb, auto_keywords, start_idx=1)
        return cmb

    def populate_default_params(self):
        lang_idx_map = {"tr": 1, "en": 2, "zh": 3, "es": 4}
        lang_idx = lang_idx_map.get(self.current_lang, 1)
        bold_font = QFont("Segoe UI", 10, QFont.Bold)
        num_font = QFont("Segoe UI", 10, QFont.DemiBold)

        self.tbl_params.setRowCount(0)
        for row_idx, item in enumerate(DEFAULT_MPYY_FACILITIES):
            self.tbl_params.insertRow(row_idx)
            self.tbl_params.setRowHeight(row_idx, 36)

            name_cell = QTableWidgetItem(create_color_swatch_icon(item[11]), str(item[lang_idx]))
            name_cell.setData(Qt.UserRole, item[0])
            name_cell.setFont(bold_font)
            name_cell.setForeground(QColor("#0f172a"))
            self.tbl_params.setItem(row_idx, 0, name_cell)

            cmb = self._create_poly_layer_combo(auto_keywords=item[12])
            self.tbl_params.setCellWidget(row_idx, 1, cmb)

            for col_idx, val_idx in enumerate(range(5, 11), start=2):
                cell = QTableWidgetItem(str(item[val_idx]))
                cell.setFont(num_font)
                cell.setForeground(QColor("#0f172a"))
                cell.setTextAlignment(Qt.AlignCenter)
                if col_idx == 5:
                    cell.setBackground(QColor("#eff6ff"))
                    cell.setForeground(QColor("#1d4ed8"))
                self.tbl_params.setItem(row_idx, col_idx, cell)

    def reset_and_populate(self):
        self.populate_default_params()
        self.populate_layers()

    def add_facility_row(self):
        t = TRANSLATIONS[self.current_lang]
        r = self.tbl_params.rowCount()
        self.tbl_params.insertRow(r)
        self.tbl_params.setRowHeight(r, 36)
        name_cell = QTableWidgetItem(create_color_swatch_icon("#475569"), t["new_fac"])
        name_cell.setData(Qt.UserRole, f"custom_{r}")
        name_cell.setFont(QFont("Segoe UI", 10, QFont.Bold))
        self.tbl_params.setItem(r, 0, name_cell)
        cmb = self._create_poly_layer_combo()
        self.tbl_params.setCellWidget(r, 1, cmb)
        defaults = ["500.0", "500.0", "1.0", "1000.0", "5000.0", "2500"]
        for c_offset, val in enumerate(defaults, start=2):
            item = QTableWidgetItem(val)
            item.setTextAlignment(Qt.AlignCenter)
            self.tbl_params.setItem(r, c_offset, item)

    def remove_selected_facility_row(self):
        cur_row = self.tbl_params.currentRow()
        if cur_row >= 0:
            self.tbl_params.removeRow(cur_row)

    def populate_layers(self):
        self.cmb_network.clear()
        self.cmb_residential_poly.clear()
        self.cmb_vacant_polys.clear()

        layers = QgsProject.instance().mapLayers().values()
        for lyr in layers:
            if not isinstance(lyr, QgsVectorLayer):
                continue
            if lyr.name().startswith("MPYY_"):
                continue
            geom_type = lyr.geometryType()
            if geom_type == QgsWkbTypes.LineGeometry:
                self.cmb_network.addItem(lyr.name(), lyr)
            elif geom_type == QgsWkbTypes.PolygonGeometry:
                self.cmb_residential_poly.addItem(lyr.name(), lyr)
                self.cmb_vacant_polys.addItem(lyr.name(), lyr)

        self._auto_select_combo(self.cmb_network, ["prepared", "yol", "network", "ag", "road"])
        self._auto_select_combo(self.cmb_residential_poly, ["konut_adalari", "mevcut_konut", "konut", "yerlesim"])
        self._auto_select_combo(self.cmb_vacant_polys, ["mevcut_bos", "bos_alan", "bos_imar", "bos_ada", "bos", "vacant"])

        for r in range(self.tbl_params.rowCount()):
            name_item = self.tbl_params.item(r, 0)
            key_id = name_item.data(Qt.UserRole) if name_item else ""
            fac_name = name_item.text().strip().lower() if name_item else ""
            old_cmb = self.tbl_params.cellWidget(r, 1)
            prev_lyr = old_cmb.currentData() if old_cmb else None

            kw = [fac_name]
            for item in DEFAULT_MPYY_FACILITIES:
                if item[0] == key_id:
                    kw = item[12]
                    break

            new_cmb = self._create_poly_layer_combo(auto_keywords=kw)
            if prev_lyr is not None:
                for i in range(new_cmb.count()):
                    if new_cmb.itemData(i) == prev_lyr:
                        new_cmb.setCurrentIndex(i)
                        break
            self.tbl_params.setCellWidget(r, 1, new_cmb)

    def _auto_select_combo(self, combo, keywords, start_idx=0):
        for kw in keywords:
            for i in range(start_idx, combo.count()):
                txt = combo.itemText(i).lower()
                if kw in txt:
                    combo.setCurrentIndex(i)
                    return

    def read_parameters_table(self):
        specs = {}
        color_lookup = {item[0]: item[11] for item in DEFAULT_MPYY_FACILITIES}
        for r in range(self.tbl_params.rowCount()):
            try:
                name_item = self.tbl_params.item(r, 0)
                name = name_item.text().strip() if name_item else ""
                if not name:
                    continue
                key_id = name_item.data(Qt.UserRole) or name
                cmb = self.tbl_params.cellWidget(r, 1)
                poly_lyr = cmb.currentData() if cmb else None

                euclid_r = float(self.tbl_params.item(r, 2).text().replace(",", "."))
                net_r = float(self.tbl_params.item(r, 3).text().replace(",", "."))
                std_m2 = float(self.tbl_params.item(r, 4).text().replace(",", "."))
                min_area = float(self.tbl_params.item(r, 5).text().replace(",", "."))
                max_single = float(self.tbl_params.item(r, 6).text().replace(",", "."))
                unit_cap = float(self.tbl_params.item(r, 7).text().replace(",", "."))

                specs[name] = {
                    "key_id": key_id,
                    "name": name,
                    "layer": poly_lyr,
                    "euclid_r": euclid_r,
                    "net_r": net_r,
                    "std_m2": std_m2,
                    "min_area": min_area,
                    "max_single": max_single,
                    "unit_cap": unit_cap,
                    "color": color_lookup.get(key_id, "#475569")
                }
            except Exception:
                continue
        return specs

    def _find_park_category_name(self, specs):
        for cat, sp in specs.items():
            if sp["key_id"] == "park" or "park" in cat.lower() or "公园" in cat or "parque" in cat.lower():
                return cat
        return list(specs.keys())[-1]

    def _find_residential_growth_category_name(self, specs):
        for cat, sp in specs.items():
            if sp["key_id"] == "konut" or "konut" in cat.lower() or "residential" in cat.lower() or "居住" in cat:
                return cat
        return None

    def run_full_analysis(self):
        t = TRANSLATIONS[self.current_lang]
        net_lyr = self.cmb_network.currentData()
        res_poly_lyr = self.cmb_residential_poly.currentData()
        vac_poly_lyr = self.cmb_vacant_polys.currentData()

        if not all([net_lyr, res_poly_lyr, vac_poly_lyr]):
            QMessageBox.warning(self, t["warn_missing_title"], t["warn_missing_msg"])
            return

        specs = self.read_parameters_table()
        if not specs:
            return

        self.btn_run.setEnabled(False)
        self.progress.setValue(5)
        QApplication.processEvents()

        try:
            total_pop = float(self.spn_population.value())
            work_crs = vac_poly_lyr.crs()
            crs_auth = work_crs.authid()
            park_cat = self._find_park_category_name(specs)
            res_growth_cat = self._find_residential_growth_category_name(specs)

            graph = FastRoadGraph(net_lyr, target_crs=work_crs, tolerance=2.5)
            self.progress.setValue(20)
            QApplication.processEvents()

            fac_by_type = {k: [] for k in specs.keys()}
            existing_cap_by_type = {k: 0.0 for k in specs.keys()}

            fac_pts_lyr = QgsVectorLayer(f"Point?crs={crs_auth}", "MPYY_Mevcut_Donati_Agirlik_Merkezleri", "memory")
            fac_pts_pr = fac_pts_lyr.dataProvider()
            fac_pts_pr.addAttributes([
                QgsField("donati_turu", QVariant.String),
                QgsField("kaynak_id", QVariant.Int),
                QgsField("alan_m2", QVariant.Double),
                QgsField("birim_kapasite", QVariant.Int)
            ])
            fac_pts_lyr.updateFields()
            fac_pt_features = []

            for cat, sp in specs.items():
                if sp["key_id"] == "konut":
                    continue
                lyr = sp["layer"]
                unit_cap = sp["unit_cap"]
                if lyr is None:
                    continue
                xform = None
                if lyr.crs() != work_crs:
                    xform = QgsCoordinateTransform(lyr.crs(), work_crs, QgsProject.instance())
                for feat in lyr.getFeatures():
                    geom = feat.geometry()
                    if not geom or geom.isEmpty():
                        continue
                    if xform is not None:
                        geom = QgsGeometry(geom)
                        geom.transform(xform)
                    pt = geom.centroid().asPoint()
                    area_m2 = geom.area() if lyr.geometryType() == QgsWkbTypes.PolygonGeometry else 0.0
                    fac_by_type[cat].append((feat.id(), pt, unit_cap, area_m2))
                    existing_cap_by_type[cat] += unit_cap

                    f_pt = QgsFeature(fac_pts_lyr.fields())
                    f_pt.setGeometry(QgsGeometry.fromPointXY(pt))
                    f_pt["donati_turu"] = cat
                    f_pt["kaynak_id"] = feat.id()
                    f_pt["alan_m2"] = round(area_m2, 1)
                    f_pt["birim_kapasite"] = int(unit_cap)
                    fac_pt_features.append(f_pt)

            fac_pts_pr.addFeatures(fac_pt_features)
            fac_pts_lyr.updateExtents()
            self.progress.setValue(35)
            QApplication.processEvents()

            max_cutoff = max([v["net_r"] for v in specs.values()] + [2500.0]) * 1.25
            net_dist_maps = {}
            for cat, items in fac_by_type.items():
                pts = [it[1] for it in items]
                if pts:
                    net_dist_maps[cat] = graph.multi_source_dijkstra(pts, max_cutoff=max_cutoff)
                else:
                    net_dist_maps[cat] = {}
                QApplication.processEvents()

            self.progress.setValue(50)

            res_feats = []
            total_res_area = 0.0
            res_xform = None
            if res_poly_lyr.crs() != work_crs:
                res_xform = QgsCoordinateTransform(res_poly_lyr.crs(), work_crs, QgsProject.instance())

            for rf in res_poly_lyr.getFeatures():
                g = rf.geometry()
                if g and not g.isEmpty():
                    if res_xform is not None:
                        g = QgsGeometry(g)
                        g.transform(res_xform)
                    a = max(g.area(), 1.0)
                    pt = g.centroid().asPoint()
                    nid, snap_d = graph.snap_point_to_node(pt)
                    res_feats.append((rf.id(), pt, a, nid, snap_d))
                    total_res_area += a

            if total_res_area <= 0:
                total_res_area = 1.0

            res_out_lyr = QgsVectorLayer(f"Point?crs={crs_auth}", "MPYY_Konut_Agirlik_Merkezleri_Erisim", "memory")
            res_pr = res_out_lyr.dataProvider()
            res_fields = QgsFields()
            res_fields.append(QgsField("ada_id", QVariant.Int))
            res_fields.append(QgsField("ada_alan_m2", QVariant.Double))
            res_fields.append(QgsField("tahmini_nufus", QVariant.Double))
            for cat in specs.keys():
                if specs[cat]["key_id"] == "konut":
                    continue
                short_c = cat[:10].replace(" ", "_")
                res_fields.append(QgsField(f"{short_c}_kus_m", QVariant.Double))
                res_fields.append(QgsField(f"{short_c}_yol_m", QVariant.Double))
                res_fields.append(QgsField(f"{short_c}_durum", QVariant.String))
            res_fields.append(QgsField("eksik_donatilar", QVariant.String))
            res_fields.append(QgsField("aciklama_raporu", QVariant.String))
            res_pr.addAttributes(res_fields)
            res_out_lyr.updateFields()

            unserved_pop_by_cat = {k: 0.0 for k in specs.keys() if specs[k]["key_id"] != "konut"}
            bird_ok_road_fail_count = {k: 0 for k in specs.keys() if specs[k]["key_id"] != "konut"}
            unserved_res_nodes = {k: [] for k in specs.keys() if specs[k]["key_id"] != "konut"}

            out_res_features = []
            for idx_r, (r_id, pt, r_area, r_nid, r_snap) in enumerate(res_feats):
                if idx_r % 50 == 0:
                    QApplication.processEvents()
                ada_pop = total_pop * (r_area / total_res_area)

                new_f = QgsFeature(res_out_lyr.fields())
                new_f.setGeometry(QgsGeometry.fromPointXY(pt))
                new_f["ada_id"] = r_id
                new_f["ada_alan_m2"] = round(r_area, 1)
                new_f["tahmini_nufus"] = round(ada_pop, 1)

                eksikler = []
                rapor_satirlari = []

                for cat, sp in specs.items():
                    if sp["key_id"] == "konut":
                        continue
                    short_c = cat[:10].replace(" ", "_")
                    items = fac_by_type[cat]
                    if items:
                        d_bird = min(math.hypot(pt.x() - it[1].x(), pt.y() - it[1].y()) for it in items)
                    else:
                        d_bird = float('inf')

                    d_map = net_dist_maps[cat]
                    if r_nid is not None and r_nid in d_map:
                        d_road = d_map[r_nid] + r_snap
                    else:
                        d_road = float('inf')

                    new_f[f"{short_c}_kus_m"] = round(d_bird, 1) if d_bird < 1e8 else -1.0
                    new_f[f"{short_c}_yol_m"] = round(d_road, 1) if d_road < 1e8 else -1.0

                    bird_ok = (d_bird <= sp["euclid_r"])
                    road_ok = (d_road <= sp["net_r"])

                    if bird_ok and road_ok:
                        durum = f"OK (Bird:{int(d_bird)}m, Road:{int(d_road)}m)"
                        rapor_satirlari.append(f"{cat}: OK ({int(d_road)}m).")
                    elif bird_ok and not road_ok:
                        durum = f"BIRD OK ({int(d_bird)}m) / NO ROAD ACCESS (>{int(sp['net_r'])}m)"
                        bird_ok_road_fail_count[cat] += 1
                        unserved_pop_by_cat[cat] += ada_pop
                        unserved_res_nodes[cat].append([pt, ada_pop, r_nid, r_snap, False])
                        eksikler.append(cat)
                        rapor_satirlari.append(f"{cat}: Bird OK ({int(d_bird)}m) but Road FAIL.")
                    else:
                        durum = f"NO ACCESS"
                        unserved_pop_by_cat[cat] += ada_pop
                        unserved_res_nodes[cat].append([pt, ada_pop, r_nid, r_snap, False])
                        eksikler.append(cat)
                        rapor_satirlari.append(f"{cat}: No Access.")

                    new_f[f"{short_c}_durum"] = durum

                new_f["eksik_donatilar"] = ", ".join(eksikler) if eksikler else "OK"
                new_f["aciklama_raporu"] = " | ".join(rapor_satirlari)
                out_res_features.append(new_f)

            res_pr.addFeatures(out_res_features)
            res_out_lyr.updateExtents()
            self.progress.setValue(70)
            QApplication.processEvents()

            alloc_lyr = QgsVectorLayer(f"Polygon?crs={crs_auth}", "MPYY_Onerilen_ve_Bolunen_Donati_Alanlari", "memory")
            alloc_pr = alloc_lyr.dataProvider()
            alloc_fields = QgsFields()
            alloc_fields.append(QgsField("kaynak_ada_id", QVariant.Int))
            alloc_fields.append(QgsField("parca_no", QVariant.Int))
            alloc_fields.append(QgsField("onerilen_donati", QVariant.String))
            alloc_fields.append(QgsField("alan_m2", QVariant.Double))
            alloc_fields.append(QgsField("hedef_nufus_etki", QVariant.Int))
            alloc_fields.append(QgsField("yol_erisim_skoru", QVariant.Double))
            alloc_fields.append(QgsField("mevcut_durum_ozeti", QVariant.String))
            alloc_fields.append(QgsField("planlama_aciklama_raporu", QVariant.String))
            alloc_pr.addAttributes(alloc_fields)
            alloc_lyr.updateFields()

            vac_pts_lyr = QgsVectorLayer(f"Point?crs={crs_auth}", "MPYY_Bos_Alan_Agirlik_Merkezleri", "memory")
            vac_pts_pr = vac_pts_lyr.dataProvider()
            vac_pts_pr.addAttributes([
                QgsField("kaynak_ada_id", QVariant.Int),
                QgsField("alan_m2", QVariant.Double),
                QgsField("atanan_donatilar", QVariant.String)
            ])
            vac_pts_lyr.updateFields()
            vac_pt_features = []

            remaining_deficit_pop = {}
            for cat, sp in specs.items():
                if sp["key_id"] == "konut":
                    continue
                cap_deficit = max(0.0, total_pop - existing_cap_by_type[cat])
                remaining_deficit_pop[cat] = max(unserved_pop_by_cat[cat], cap_deficit)

            newly_placed_points = {k: [] for k in specs.keys()}
            allocated_summary = {k: {"count": 0, "area": 0.0, "served_pop": 0} for k in specs.keys()}
            parcel_narrative_list = []
            out_alloc_features = []

            vac_features_list = list(vac_poly_lyr.getFeatures())
            total_vac = max(len(vac_features_list), 1)

            for idx_v, pf in enumerate(vac_features_list):
                if idx_v % 5 == 0:
                    pct = 70 + int(25 * (idx_v / total_vac))
                    self.progress.setValue(min(pct, 95))
                    QApplication.processEvents()

                pgeom = pf.geometry()
                if not pgeom or pgeom.isEmpty():
                    continue
                poly_area = pgeom.area()
                if poly_area < 50.0:
                    continue

                eval_pt = pgeom.centroid().asPoint()
                v_nid, v_snap = graph.snap_point_to_node(eval_pt)
                vac_dist_map = graph.multi_source_dijkstra([eval_pt], max_cutoff=2600.0)

                iyi_olanlar = []
                aday_donatilar = []

                total_active_deficit = sum(remaining_deficit_pop.values()) + sum(len(lst) for lst in unserved_res_nodes.values())
                surplus_facilities = (total_active_deficit <= 500.0 and poly_area >= 1200.0)

                if surplus_facilities and res_growth_cat:
                    fallback_cat = res_growth_cat
                    f_new = QgsFeature(alloc_lyr.fields())
                    f_new.setGeometry(pgeom)
                    f_new["kaynak_ada_id"] = pf.id()
                    f_new["parca_no"] = 1
                    f_new["onerilen_donati"] = fallback_cat
                    f_new["alan_m2"] = round(poly_area, 1)
                    f_new["hedef_nufus_etki"] = int(round(poly_area / 35.0))
                    f_new["yol_erisim_skoru"] = 100.0
                    f_new["mevcut_durum_ozeti"] = "Çevredeki donatılar yeterli (Fazla donatı yığılması önlendi)"
                    aciklama = (
                        f"Ada #{pf.id()} ({int(poly_area)} m²): Bölgedeki mevcut okul, ibadet ve sosyal tesis kapasiteleri "
                        f"nüfus talebini fazlasıyla karşıladığından, gerçekçi şehircilik ilkeleri gereği bu alana ek donatı "
                        f"konulmamış; bölge nüfus gelişimi ve konut ihtiyacını desteklemek üzere '{fallback_cat}' olarak ayrılmıştır."
                    )
                    f_new["planlama_aciklama_raporu"] = aciklama
                    out_alloc_features.append(f_new)
                    allocated_summary[fallback_cat]["count"] += 1
                    allocated_summary[fallback_cat]["area"] += poly_area
                    parcel_narrative_list.append(aciklama)

                    v_pt_f = QgsFeature(vac_pts_lyr.fields())
                    v_pt_f.setGeometry(QgsGeometry.fromPointXY(eval_pt))
                    v_pt_f["kaynak_ada_id"] = pf.id()
                    v_pt_f["alan_m2"] = round(poly_area, 1)
                    v_pt_f["atanan_donatilar"] = fallback_cat
                    vac_pt_features.append(v_pt_f)
                    continue

                for cat, sp in specs.items():
                    if sp["key_id"] == "konut":
                        continue
                    d_map = net_dist_maps[cat]
                    d_to_existing = (d_map[v_nid] + v_snap) if (v_nid is not None and v_nid in d_map) else float('inf')

                    d_to_newly_placed = float('inf')
                    for np_pt, np_nid, np_snap in newly_placed_points[cat]:
                        db = math.hypot(eval_pt.x() - np_pt.x(), eval_pt.y() - np_pt.y())
                        dr = (vac_dist_map[np_nid] + np_snap) if (np_nid is not None and np_nid in vac_dist_map) else db * 1.3
                        d_to_newly_placed = min(d_to_newly_placed, db, dr)

                    effective_d = min(d_to_existing, d_to_newly_placed)
                    cap_ok = (existing_cap_by_type[cat] >= total_pop and remaining_deficit_pop[cat] <= 0)
                    too_close_to_same = (cat != park_cat and d_to_newly_placed < sp["net_r"] * 0.65)

                    if (effective_d <= sp["net_r"] and cap_ok) or too_close_to_same:
                        iyi_olanlar.append(f"{cat} ({int(effective_d)}m)")
                    else:
                        newly_covered_pop = 0.0
                        net_limit = sp["net_r"]
                        for node_entry in unserved_res_nodes[cat]:
                            if not node_entry[4]:
                                r_nid, r_snap = node_entry[2], node_entry[3]
                                if r_nid is not None and r_nid in vac_dist_map:
                                    if (vac_dist_map[r_nid] + r_snap) <= net_limit:
                                        newly_covered_pop += node_entry[1]

                        deficit_weight = remaining_deficit_pop[cat]
                        diversity_factor = 1.0 / (1.0 + allocated_summary[cat]["count"] * 0.45)
                        score = (newly_covered_pop * 2.2 + deficit_weight * 0.6) * diversity_factor

                        if poly_area >= sp["min_area"] and score > 10.0:
                            aday_donatilar.append({
                                "cat": cat,
                                "sp": sp,
                                "newly_covered_pop": newly_covered_pop,
                                "score": score,
                                "d_existing": effective_d
                            })

                aday_donatilar.sort(key=lambda x: x["score"], reverse=True)
                iyi_str = ", ".join(iyi_olanlar) if iyi_olanlar else "Yok"

                if not aday_donatilar:
                    fallback_cat = park_cat
                    f_new = QgsFeature(alloc_lyr.fields())
                    f_new.setGeometry(pgeom)
                    f_new["kaynak_ada_id"] = pf.id()
                    f_new["parca_no"] = 1
                    f_new["onerilen_donati"] = fallback_cat
                    f_new["alan_m2"] = round(poly_area, 1)
                    f_new["hedef_nufus_etki"] = int(round(poly_area / max(specs[fallback_cat]["std_m2"], 1.0)))
                    f_new["yol_erisim_skoru"] = 100.0
                    f_new["mevcut_durum_ozeti"] = f"Uygun: {iyi_str}"
                    aciklama = (
                        f"Ada #{pf.id()} ({int(poly_area)} m²): Çevrede {iyi_str} erişimi yeterli olduğundan "
                        f"açık ve yeşil alan dengesini artırmak üzere '{fallback_cat}' atanmıştır."
                    )
                    f_new["planlama_aciklama_raporu"] = aciklama
                    out_alloc_features.append(f_new)
                    allocated_summary[fallback_cat]["count"] += 1
                    allocated_summary[fallback_cat]["area"] += poly_area
                    parcel_narrative_list.append(aciklama)
                    continue

                primary = aday_donatilar[0]
                p_cat = primary["cat"]
                p_sp = primary["sp"]

                target_primary_area = max(p_sp["min_area"], min(poly_area * 0.50, p_sp["max_single"]))
                rem_area = poly_area - target_primary_area
                park_min = specs[park_cat]["min_area"] if park_cat in specs else 200.0

                should_split = (
                    self.chk_auto_split.isChecked()
                    and p_cat != park_cat
                    and rem_area >= park_min
                )

                if not should_split:
                    etki_nufus = int(max(primary["newly_covered_pop"], p_sp["unit_cap"]))
                    f_new = QgsFeature(alloc_lyr.fields())
                    f_new.setGeometry(pgeom)
                    f_new["kaynak_ada_id"] = pf.id()
                    f_new["parca_no"] = 1
                    f_new["onerilen_donati"] = p_cat
                    f_new["alan_m2"] = round(poly_area, 1)
                    f_new["hedef_nufus_etki"] = etki_nufus
                    f_new["yol_erisim_skoru"] = round(primary["score"], 1)
                    f_new["mevcut_durum_ozeti"] = f"Mevcut: {iyi_str}"
                    aciklama = (
                        f"Ada #{pf.id()} ({int(poly_area)} m²): EK-2 Asgari Birim Alan ({int(p_sp['min_area'])} m²) koşulunu sağlayarak "
                        f"doğrudan '{p_cat}' atanmıştır (Çok katlı yapılaşma ile {int(p_sp['unit_cap'])} kişi kapasite sağlar)."
                    )
                    f_new["planlama_aciklama_raporu"] = aciklama
                    out_alloc_features.append(f_new)

                    self._register_placed_facility(
                        p_cat, eval_pt, v_nid, v_snap, vac_dist_map, p_sp["net_r"],
                        etki_nufus, poly_area, newly_placed_points, existing_cap_by_type,
                        remaining_deficit_pop, unserved_res_nodes, allocated_summary
                    )
                    parcel_narrative_list.append(aciklama)

                    v_pt_f = QgsFeature(vac_pts_lyr.fields())
                    v_pt_f.setGeometry(QgsGeometry.fromPointXY(eval_pt))
                    v_pt_f["kaynak_ada_id"] = pf.id()
                    v_pt_f["alan_m2"] = round(poly_area, 1)
                    v_pt_f["atanan_donatilar"] = p_cat
                    vac_pt_features.append(v_pt_f)
                else:
                    second_cat = park_cat
                    for cand in aday_donatilar[1:]:
                        if cand["cat"] != p_cat and rem_area >= cand["sp"]["min_area"]:
                            if cand["score"] > primary["score"] * 0.35:
                                second_cat = cand["cat"]
                            break

                    if second_cat != park_cat and (rem_area - specs[second_cat]["min_area"]) >= park_min * 1.5:
                        second_area = max(specs[second_cat]["min_area"], rem_area * 0.55)
                        third_area = rem_area - second_area
                        split_cats = [p_cat, second_cat, park_cat]
                        ratios = [target_primary_area, second_area, third_area]
                    else:
                        split_cats = [p_cat, second_cat]
                        ratios = [target_primary_area, rem_area]

                    sub_geoms = split_polygon_by_ratios(pgeom, ratios)
                    parca_detaylari = []

                    for idx_s, s_geom in enumerate(sub_geoms):
                        s_cat = split_cats[min(idx_s, len(split_cats) - 1)]
                        s_sp = specs[s_cat]
                        s_area = s_geom.area()
                        s_etki = int(s_sp["unit_cap"])
                        parca_detaylari.append(f"Parça {idx_s+1}: {int(s_area)} m² '{s_cat}' (EK-2 Min:{int(s_sp['min_area'])}m², Kapasite:{s_etki} kişi)")

                    ortak_aciklama = (
                        f"Ada #{pf.id()} (Toplam {int(poly_area)} m²): '{p_cat}' için EK-2 Asgari Birim Alanı {int(p_sp['min_area'])} m² "
                        f"(3-5 katlı kompakt yapı) esas alınarak ada {len(sub_geoms)} parçaya bölünmüştür: "
                        + " + ".join(parca_detaylari)
                        + ". Böylece kalan alan tek bir donatıya kapatılmamış, park ve diğer donatılara olanak tanınmıştır."
                    )

                    for idx_s, s_geom in enumerate(sub_geoms):
                        s_cat = split_cats[min(idx_s, len(split_cats) - 1)]
                        s_sp = specs[s_cat]
                        s_area = s_geom.area()
                        s_etki = int(s_sp["unit_cap"])
                        s_pt = s_geom.centroid().asPoint()
                        s_nid, s_snap = graph.snap_point_to_node(s_pt)

                        f_new = QgsFeature(alloc_lyr.fields())
                        f_new.setGeometry(s_geom)
                        f_new["kaynak_ada_id"] = pf.id()
                        f_new["parca_no"] = idx_s + 1
                        f_new["onerilen_donati"] = s_cat
                        f_new["alan_m2"] = round(s_area, 1)
                        f_new["hedef_nufus_etki"] = s_etki
                        f_new["yol_erisim_skoru"] = round(primary["score"], 1)
                        f_new["mevcut_durum_ozeti"] = f"Mevcut: {iyi_str}"
                        f_new["planlama_aciklama_raporu"] = ortak_aciklama
                        out_alloc_features.append(f_new)

                        self._register_placed_facility(
                            s_cat, s_pt, s_nid, s_snap, vac_dist_map, s_sp["net_r"],
                            s_etki, s_area, newly_placed_points, existing_cap_by_type,
                            remaining_deficit_pop, unserved_res_nodes, allocated_summary
                        )

                    parcel_narrative_list.append(ortak_aciklama)

                    v_pt_f = QgsFeature(vac_pts_lyr.fields())
                    v_pt_f.setGeometry(QgsGeometry.fromPointXY(eval_pt))
                    v_pt_f["kaynak_ada_id"] = pf.id()
                    v_pt_f["alan_m2"] = round(poly_area, 1)
                    v_pt_f["atanan_donatilar"] = " + ".join(split_cats)
                    vac_pt_features.append(v_pt_f)

            alloc_pr.addFeatures(out_alloc_features)
            alloc_lyr.updateExtents()
            vac_pts_pr.addFeatures(vac_pt_features)
            vac_pts_lyr.updateExtents()

            self.apply_polygon_symbology(alloc_lyr, specs)
            QgsProject.instance().addMapLayer(alloc_lyr)

            if self.chk_show_centroids.isChecked():
                QgsProject.instance().addMapLayer(res_out_lyr)
                QgsProject.instance().addMapLayer(fac_pts_lyr)
                QgsProject.instance().addMapLayer(vac_pts_lyr)

            html_report = self.build_html_report(
                total_pop, specs, fac_by_type, existing_cap_by_type,
                unserved_pop_by_cat, bird_ok_road_fail_count,
                allocated_summary, parcel_narrative_list
            )
            self.txt_report.setHtml(html_report)
            self.tabs.setCurrentIndex(1)
            self.progress.setValue(100)

            QMessageBox.information(self, t["done_title"], t["done_msg"])
        finally:
            self.btn_run.setEnabled(True)

    def _register_placed_facility(
        self, cat, pt, nid, snap_d, vac_dist_map, net_limit,
        added_cap, added_area, newly_placed_points, existing_cap_by_type,
        remaining_deficit_pop, unserved_res_nodes, allocated_summary
    ):
        newly_placed_points[cat].append((pt, nid, snap_d))
        existing_cap_by_type[cat] += added_cap
        remaining_deficit_pop[cat] = max(0.0, remaining_deficit_pop[cat] - added_cap)
        allocated_summary[cat]["count"] += 1
        allocated_summary[cat]["area"] += added_area
        allocated_summary[cat]["served_pop"] += added_cap

        for node_entry in unserved_res_nodes[cat]:
            if not node_entry[4]:
                r_nid, r_snap = node_entry[2], node_entry[3]
                if r_nid is not None and r_nid in vac_dist_map:
                    if (vac_dist_map[r_nid] + r_snap) <= net_limit:
                        node_entry[4] = True

    def apply_polygon_symbology(self, layer, specs):
        categories = []
        used_names = set()
        for feat in layer.getFeatures():
            val = feat["onerilen_donati"]
            if val and val not in used_names:
                used_names.add(val)
                col_hex = specs[val]["color"] if val in specs else "#334155"
                sym = QgsFillSymbol.createSimple({
                    'color': col_hex,
                    'outline_color': '#ffffff',
                    'outline_width': '0.55'
                })
                sym.setOpacity(0.85)
                cat = QgsRendererCategory(val, sym, val)
                categories.append(cat)
        if categories:
            renderer = QgsCategorizedSymbolRenderer("onerilen_donati", categories)
            layer.setRenderer(renderer)
            layer.triggerRepaint()

    def build_html_report(
        self, total_pop, specs, fac_by_type, existing_cap_by_type,
        unserved_pop_by_cat, bird_ok_road_fail_count,
        allocated_summary, parcel_narrative_list
    ):
        rows_html = ""
        for cat, sp in specs.items():
            if sp["key_id"] == "konut":
                continue
            mevcut_adet = len(fac_by_type[cat])
            en_az_m2 = int(sp["min_area"])
            erismeyen_nufus = int(unserved_pop_by_cat[cat])
            kus_var_yol_yok = bird_ok_road_fail_count[cat]
            yeni_adet = allocated_summary[cat]["count"]
            yeni_alan = int(allocated_summary[cat]["area"])
            toplam_kap = int(existing_cap_by_type[cat])

            rows_html += f"""
            <tr>
                <td><span style='display:inline-block;width:12px;height:12px;background:{sp['color']};margin-right:6px;border-radius:2px;'></span><b>{cat}</b></td>
                <td align='center'>{int(sp['euclid_r'])} m / {int(sp['net_r'])} m</td>
                <td align='center' style='color:#1d4ed8; font-weight:bold;'>EK-2 Asgari: {en_az_m2:,} m²</td>
                <td align='center'>{mevcut_adet}</td>
                <td align='center' style='color:#d97706; font-weight:bold;'>{kus_var_yol_yok}</td>
                <td align='center'>{erismeyen_nufus:,}</td>
                <td align='center' style='background-color:#ecfdf5;'><b>+{yeni_adet} parsel ({yeni_alan:,} m²)</b></td>
                <td align='center'><b>{toplam_kap:,} kişi</b></td>
            </tr>
            """

        narratives_html = "".join([f"<li style='margin-bottom:8px;'>{n}</li>" for n in parcel_narrative_list])

        return f"""
        <html>
        <body style='font-family: Segoe UI, Arial, sans-serif; color: #1e293b;'>
            <h2 style='color:#1e3a8a; border-bottom: 2px solid #1e3a8a; padding-bottom:6px;'>
                MPYY EK-2 TABLOSU VE ASGARİ BİRİM ALAN OPTİMİZASYON RAPORU
            </h2>
            <p>
                <b>Developer / Author:</b> Baran Adsuna<br>
                <b>Planlama Nüfusu:</b> {int(total_pop):,} Kişi<br>
                <b>EK-2 Tablo ve Asgari Alan Mantığı:</b> Mekânsal Planlar Yapım Yönetmeliği Ek-2 tablosundaki resmi kişi başı standartlar
                ve asgari birim alanlar (İlkokul için 5.000-8.000 m², Ortaokul için 6.000-10.000 m², ASM için 750-2.000 m²)
                esas alınarak çok katlı yapılaşma ile kapasite sağlanmış ve adanın geri kalan kısmı Park veya diğer eksik donatılara bölünmüştür.
            </p>
            <table border='1' cellspacing='0' cellpadding='6' width='100%' style='border-collapse:collapse; font-size:12px;'>
                <tr style='background-color:#0f172a; color:white;'>
                    <th>Donatı Türü</th>
                    <th>Kuş Uçuşu / Yol Çapı</th>
                    <th>EK-2 Asgari Birim Alan (Min m²)</th>
                    <th>Mevcut Bina</th>
                    <th>Kuş Uçuşu VAR / Yol YOK</th>
                    <th>Başlangıçta Erişemeyen Nüfus</th>
                    <th>Yeni Atanan (Kompakt Bölünmüş)</th>
                    <th>Yeni Toplam Kapasite</th>
                </tr>
                {rows_html}
            </table>
            <h3 style='margin-top:18px;'>Boş İmar Adaları (Poligon) EK-2 Bölme ve Atama Açıklamaları</h3>
            <ul style='font-size:13px; line-height:1.5;'>
                {narratives_html}
            </ul>
        </body>
        </html>
        """

    def create_demo_layers(self):
        crs = "EPSG:32635"
        base_x, base_y = 512000.0, 4254000.0

        net_lyr = QgsVectorLayer(f"LineString?crs={crs}", "Prepared_network_yol", "memory")
        net_pr = net_lyr.dataProvider()
        net_feats = []
        for y_off in [0, 300, 600, 900, 1200]:
            for x_off in [0, 300, 600, 900]:
                if y_off == 300 and x_off == 300:
                    continue
                f = QgsFeature()
                f.setGeometry(QgsGeometry.fromPolylineXY([
                    QgsPointXY(base_x + x_off, base_y + y_off),
                    QgsPointXY(base_x + x_off + 300, base_y + y_off)
                ]))
                net_feats.append(f)

        for x_off in [0, 300, 600, 900, 1200]:
            for y_off in [0, 300, 600, 900]:
                f = QgsFeature()
                f.setGeometry(QgsGeometry.fromPolylineXY([
                    QgsPointXY(base_x + x_off, base_y + y_off),
                    QgsPointXY(base_x + x_off, base_y + y_off + 300)
                ]))
                net_feats.append(f)
        net_pr.addFeatures(net_feats)
        net_lyr.updateExtents()

        def make_rect_poly(x, y, w, h):
            pts = [
                QgsPointXY(x, y),
                QgsPointXY(x + w, y),
                QgsPointXY(x + w, y + h),
                QgsPointXY(x, y + h),
                QgsPointXY(x, y)
            ]
            return QgsGeometry.fromPolygonXY([pts])

        demo_fac_layers = [
            ("mevcut_ilkokul", [(base_x + 250, base_y + 280, 80, 70)]),
            ("mevcut_lise", [(base_x + 580, base_y + 880, 80, 80)]),
        ]
        for lyr_name, boxes in demo_fac_layers:
            fl = QgsVectorLayer(f"Polygon?crs={crs}", lyr_name, "memory")
            fpr = fl.dataProvider()
            feats = []
            for bx, by, bw, bh in boxes:
                ff = QgsFeature()
                ff.setGeometry(make_rect_poly(bx, by, bw, bh))
                feats.append(ff)
            fpr.addFeatures(feats)
            fl.updateExtents()
            QgsProject.instance().addMapLayer(fl)

        res_lyr = QgsVectorLayer(f"Polygon?crs={crs}", "mevcut_konut_adalari", "memory")
        res_pr = res_lyr.dataProvider()
        res_boxes = [
            (base_x + 110, base_y + 110, 85, 80),
            (base_x + 590, base_y + 270, 75, 70),
            (base_x + 410, base_y + 410, 80, 80),
            (base_x + 710, base_y + 410, 90, 85),
            (base_x + 110, base_y + 710, 85, 75),
            (base_x + 710, base_y + 710, 95, 85),
            (base_x + 1010, base_y + 410, 85, 80),
        ]
        res_feats = []
        for bx, by, bw, bh in res_boxes:
            rf = QgsFeature()
            rf.setGeometry(make_rect_poly(bx, by, bw, bh))
            res_feats.append(rf)
        res_pr.addFeatures(res_feats)
        res_out_lyr = res_lyr

        vac_poly_lyr = QgsVectorLayer(f"Polygon?crs={crs}", "mevcut_bos1", "memory")
        vp_pr = vac_poly_lyr.dataProvider()
        vac_boxes = [
            (base_x + 560, base_y + 160, 90, 70),
            (base_x + 560, base_y + 260, 80, 65),
            (base_x + 260, base_y + 560, 50, 30),
            (base_x + 860, base_y + 260, 70, 45),
        ]
        poly_feats = []
        for bx, by, bw, bh in vac_boxes:
            pf = QgsFeature()
            pf.setGeometry(make_rect_poly(bx, by, bw, bh))
            poly_feats.append(pf)
        vp_pr.addFeatures(poly_feats)
        vac_poly_lyr.updateExtents()

        QgsProject.instance().addMapLayer(net_lyr)
        QgsProject.instance().addMapLayer(vac_poly_lyr)
        QgsProject.instance().addMapLayer(res_lyr)

        self.populate_layers()
