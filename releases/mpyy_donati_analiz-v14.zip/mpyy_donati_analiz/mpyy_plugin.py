# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from .mpyy_dialog import MPYYDonatiDialog

class MPYYDonatiPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        self.icon = QIcon(icon_path)
        self.action = QAction(
            self.icon,
            "MPYY Donatı Analizi",
            self.iface.mainWindow()
        )
        self.action.setToolTip("MPYY Donatı Erişilebilirlik ve Optimizasyon — by Baran Adsuna")
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu("&MPYY Donatı Analizi", self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginVectorMenu("&MPYY Donatı Analizi", self.action)
            self.iface.removeToolBarIcon(self.action)

    def run(self):
        if self.dialog is None:
            self.dialog = MPYYDonatiDialog(self.iface)
            self.dialog.setWindowIcon(self.icon)
        self.dialog.populate_layers()
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
