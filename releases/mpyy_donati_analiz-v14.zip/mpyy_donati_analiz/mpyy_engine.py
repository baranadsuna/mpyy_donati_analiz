# -*- coding: utf-8 -*-
import math
import heapq
from qgis.core import (
    QgsGeometry, QgsPointXY, QgsFeature, QgsRectangle,
    QgsSpatialIndex, QgsCoordinateTransform, QgsProject
)


class FastRoadGraph:
    """
    Ultra-hızlı Yol Ağı (Prepared Network) Graf Motoru.
    QgsSpatialIndex kullanarak nokta-düğüm yakalamayı (snapping) O(1) sürede yapar
    ve QGIS arayüzünün donmasını (Yanıt Vermiyor hatasını) tamamen engeller.
    """
    def __init__(self, network_layer, target_crs=None, tolerance=2.0):
        self.tolerance = tolerance
        self.nodes = []          # node_id -> QgsPointXY
        self.grid = {}           # (gx, gy) -> list of node_id
        self.adj = {}            # node_id -> list of (neighbor_id, length)
        self.sindex = QgsSpatialIndex()
        self._snap_cache = {}    # (round(x,2), round(y,2)) -> (node_id, snap_dist)
        self._build_graph(network_layer, target_crs)

    def _get_or_create_node(self, pt):
        gx = int(round(pt.x() / self.tolerance))
        gy = int(round(pt.y() / self.tolerance))
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                cell = (gx + dx, gy + dy)
                if cell in self.grid:
                    for nid in self.grid[cell]:
                        npt = self.nodes[nid]
                        if math.hypot(pt.x() - npt.x(), pt.y() - npt.y()) <= self.tolerance:
                            return nid
        nid = len(self.nodes)
        p_copy = QgsPointXY(pt.x(), pt.y())
        self.nodes.append(p_copy)
        self.adj[nid] = []
        self.grid.setdefault((gx, gy), []).append(nid)

        feat = QgsFeature(nid)
        feat.setGeometry(QgsGeometry.fromPointXY(p_copy))
        self.sindex.addFeature(feat)
        return nid

    def _build_graph(self, layer, target_crs):
        xform = None
        if target_crs is not None and layer.crs() != target_crs:
            xform = QgsCoordinateTransform(layer.crs(), target_crs, QgsProject.instance())

        for feat in layer.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue
            if xform is not None:
                geom = QgsGeometry(geom)
                geom.transform(xform)

            lines = geom.asMultiPolyline() if geom.isMultipart() else [geom.asPolyline()]
            for line in lines:
                n_pts = len(line)
                if n_pts < 2:
                    continue
                # Sadece uç noktaları ve kavşak kırıklarını makul aralıklarla düğüm yap
                prev_u = self._get_or_create_node(line[0])
                acc_len = 0.0
                for i in range(1, n_pts):
                    p1 = line[i - 1]
                    p2 = line[i]
                    seg_len = math.hypot(p2.x() - p1.x(), p2.y() - p1.y())
                    acc_len += seg_len
                    # Ara noktaları yalnızca 15m'den uzunsa veya son noktaysa düğümle (graf şişmesini önler)
                    if i == n_pts - 1 or acc_len >= 15.0:
                        if acc_len > 0.001:
                            v = self._get_or_create_node(p2)
                            if prev_u != v:
                                self.adj[prev_u].append((v, acc_len))
                                self.adj[v].append((prev_u, acc_len))
                            prev_u = v
                            acc_len = 0.0

    def snap_point_to_node(self, pt):
        """
        QgsSpatialIndex + önbellek (cache) ile O(1) sürede en yakın yol düğümünü bulur.
        """
        if not self.nodes:
            return None, float('inf')
        key = (round(pt.x(), 1), round(pt.y(), 1))
        if key in self._snap_cache:
            return self._snap_cache[key]

        nearest_ids = self.sindex.nearestNeighbor(pt, 1)
        if nearest_ids:
            nid = nearest_ids[0]
            npt = self.nodes[nid]
            d = math.hypot(pt.x() - npt.x(), pt.y() - npt.y())
            self._snap_cache[key] = (nid, d)
            return nid, d

        self._snap_cache[key] = (None, float('inf'))
        return None, float('inf')

    def multi_source_dijkstra(self, source_points, max_cutoff=4000.0):
        """
        Verilen noktalardan ağ üzerindeki tüm düğümlere en kısa mesafeyi hesaplar.
        """
        dist = {}
        pq = []
        for pt in source_points:
            nid, snap_d = self.snap_point_to_node(pt)
            if nid is not None and snap_d <= max_cutoff:
                if nid not in dist or snap_d < dist[nid]:
                    dist[nid] = snap_d
                    heapq.heappush(pq, (snap_d, nid))

        while pq:
            d, u = heapq.heappop(pq)
            if d > dist.get(u, float('inf')):
                continue
            if d > max_cutoff:
                continue
            for v, w in self.adj.get(u, ()):
                nd = d + w
                if nd <= max_cutoff and nd < dist.get(v, float('inf')):
                    dist[v] = nd
                    heapq.heappush(pq, (nd, v))
        return dist

    def distance_from_map(self, dist_map, target_pt):
        if not dist_map:
            return float('inf')
        nid, snap_d = self.snap_point_to_node(target_pt)
        if nid is None or nid not in dist_map:
            return float('inf')
        return dist_map[nid] + snap_d


def split_polygon_by_ratios(poly_geom, ratios):
    """
    Bir poligonu verilen alan oranlarına göre hızlı ikili arama (12 adım) ile böler.
    """
    if not poly_geom or poly_geom.isEmpty():
        return []
    total_ratio = sum(ratios)
    if total_ratio <= 0 or len(ratios) <= 1:
        return [poly_geom]

    norm_ratios = [r / total_ratio for r in ratios]
    parts = []
    remaining = QgsGeometry(poly_geom)

    for i in range(len(norm_ratios) - 1):
        if not remaining or remaining.isEmpty():
            break
        rem_ratio_sum = sum(norm_ratios[i:])
        target_frac = norm_ratios[i] / rem_ratio_sum
        target_area = remaining.area() * target_frac

        bbox = remaining.boundingBox()
        xmin, xmax = bbox.xMinimum(), bbox.xMaximum()
        ymin, ymax = bbox.yMinimum(), bbox.yMaximum()
        split_along_x = (xmax - xmin) >= (ymax - ymin)

        low = xmin if split_along_x else ymin
        high = xmax if split_along_x else ymax
        best_left = None

        for _ in range(12):
            mid = (low + high) * 0.5
            if split_along_x:
                rect = QgsRectangle(xmin - 1.0, ymin - 1.0, mid, ymax + 1.0)
            else:
                rect = QgsRectangle(xmin - 1.0, ymin - 1.0, xmax + 1.0, mid)
            clip_geom = QgsGeometry.fromRect(rect)
            left_piece = remaining.intersection(clip_geom)
            a = left_piece.area() if (left_piece and not left_piece.isEmpty()) else 0.0
            if a < target_area:
                low = mid
            else:
                high = mid
            best_left = left_piece

        if best_left and not best_left.isEmpty():
            best_right = remaining.difference(best_left)
            parts.append(best_left)
            if best_right and not best_right.isEmpty():
                remaining = best_right
            else:
                remaining = None
                break
        else:
            break

    if remaining and not remaining.isEmpty():
        parts.append(remaining)

    return parts if parts else [poly_geom]
